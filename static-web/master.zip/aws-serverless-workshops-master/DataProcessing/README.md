# Serverless Data Processing on AWS

This module is now available at
[https://dataprocessing.wildrydes.com](https://dataprocessing.wildrydes.com).
